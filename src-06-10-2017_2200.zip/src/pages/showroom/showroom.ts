import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-showroom',
  templateUrl: 'showroom.html'
})
export class ShowroomPage {

  constructor(public navCtrl: NavController) {

  }

}
