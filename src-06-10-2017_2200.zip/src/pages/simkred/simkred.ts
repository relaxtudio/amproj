import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-simkred',
  templateUrl: 'simkred.html'
})
export class SimkredPage {

  constructor(public navCtrl: NavController) {

  }

}
